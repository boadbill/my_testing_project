import java.util.ArrayList;
import java.util.List;

public class JavaA222 {
	// Method to check if a number is prime
    public static boolean isPrime(int m) {
        if (m < 2) return false;
        for (int i = 2; i < m; i++) {
            if (m % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    // Method to list all primes up to n
    public static List<Integer> listPrimes(int n) {
        List<Integer> primes = new ArrayList<>();
        for (int i = 2; i <= n; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }
        return primes;
    }
    
    public static void main(String[] args) {
        int n = 10000;
        for (int cases = 0; cases < 7; cases++) {
            long t1 = System.currentTimeMillis();
            List<Integer> primes = listPrimes(n);
            long t2 = System.currentTimeMillis();
            
            System.out.println("n = " + n + " *** time = " + (t2 - t1) + " milliseconds");
            // Uncomment the next line if you want to print the prime numbers
            // System.out.println(primes);
            
            n *= 2;
        }
    }
}

