
public class QuicksortInsertion {
	public static void interchange(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    // Método para encontrar la mediana de tres elementos
    public static int median_of_three(int[] a, int left, int right) {
        int center = (left + right) / 2;
        if (a[left] > a[center])
            interchange(a, left, center);
        if (a[left] > a[right])
            interchange(a, left, right);
        if (a[center] > a[right])
            interchange(a, center, right);
        return center;
    }

    // Método de ordenación por inserción
    public static void insertion(int[] a, int left, int right) {
        for (int i = left + 1; i <= right; i++) {
            int pivot = a[i];
            int j = i - 1;

            while (j >= left && pivot < a[j]) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = pivot;
        }
    }

    // Método QuickSort modificado para usar Insertion Sort cuando el tamaño del subarreglo es <= k
    public static void quicksort(int[] a, int left, int right, int k) {
        if (left < right) {
            if (right - left + 1 <= k) {
                // Si el tamaño del subarreglo es menor o igual a k, usar Insertion Sort
                insertion(a, left, right);
            } else {
                // Si el tamaño del subarreglo es mayor que k, continuar con QuickSort
                int center = median_of_three(a, left, right);
                int pivot = a[center];
                interchange(a, center, right);

                int i = left;
                int j = right - 1;

                do {
                    while (a[i] <= pivot && i < right) i++;
                    while (a[j] >= pivot && j > left) j--;
                    if (i < j) interchange(a, i, j);
                } while (i < j);

                interchange(a, i, right);

                quicksort(a, left, i - 1, k);
                quicksort(a, i + 1, right, k);
            }
        }
    }

    // Método principal para ordenar el arreglo
    public static void sort(int[] a, int k) {
        quicksort(a, 0, a.length - 1, k);
    }

	    public static void main(String[] args) {
	        // Ejemplo: ordenar un vector de 20 elementos generados aleatoriamente
	        int n = 20;
	        int k = 10; // Umbral para usar insertion sort en lugar de quicksort
	        int[] vector = new int[n];

	        // Rellenamos el vector con números aleatorios entre 0 y 100.
	        java.util.Random rnd = new java.util.Random();
	        for (int i = 0; i < n; i++) {
	            vector[i] = rnd.nextInt(100);
	        }

	        System.out.println("Vector original:");
	        System.out.println(java.util.Arrays.toString(vector));

	        // Se ordena el vector usando el quicksort híbrido.
	        sort(vector, k);

	        System.out.println("Vector ordenado:");
	        System.out.println(java.util.Arrays.toString(vector));
	    }
	
}